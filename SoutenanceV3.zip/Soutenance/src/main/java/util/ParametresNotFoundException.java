package util;

public class ParametresNotFoundException extends RuntimeException
{
    public ParametresNotFoundException(String texte)
    {
        super(texte);
    }
}