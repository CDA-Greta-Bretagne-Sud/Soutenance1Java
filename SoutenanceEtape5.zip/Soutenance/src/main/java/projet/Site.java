package projet;

import java.util.*;

import util.*;

// Classe de definition du site de vente
//
public class Site {
    private ArrayList<Produit> stock;       // Les produits du stock
    private ArrayList<Commande> commandes;  // Les bons de commande
    private Map<Integer, List<Commande>> groupedCommands = new HashMap<>();
    private List<Commande> deliveredCommands = new ArrayList<>();

    public ArrayList<Commande> getCommandes() {
        return commandes;
    }

    // Constructeur
    //
    public Site() {
        stock = new ArrayList<Produit>();

        // lecture du fichier data/Produits.txt
        //  pour chaque ligne on cree un Produit que l'on ajoute a stock
        initialiserStock("data/Produits.txt");

        //  lecture du fichier data/Commandes.txt
        //  pour chaque ligne on cree une commande ou on ajoute une reference
        //  d'un produit a une commande existante.
        // AC AC

        commandes = new ArrayList<Commande>();
        initialiserCommandes("data/Commandes.txt");

    }

    // Methode qui retourne sous la forme d'une chaine de caractere
    //  tous les produits du stock
    //
    public String listerTousProduits() {
        String res = "";
        for (Produit prod : stock)
            res = res + prod.toString() + "\n";

        return res;
    }

    // Methode qui retourne sous la forme d'une chaine de caractere
    //  toutes les commandes
    //
    public String listerToutesCommandes() {


        String res = "";
        int compteur = 0;

        // Parcours toutes les commandes dans la liste en utilisant la methode listerCommande
        for (Commande comm : commandes) {
            if (comm.getNumero()!=compteur)
            res += listerCommande(comm.getNumero());
            compteur=comm.getNumero();
            ;
        }

        // Retourne la chaîne de caractères résultante
        return res;
    }

    // Methode qui retourne sous la forme d'une chaine de caractere
    //  une commande
    public String listerCommande(int numero) {
        String res = "";
        String res1 = "";
        boolean trouver = false;

        for (Commande comm : commandes) {
            if (comm.getNumero() == numero) {
                res="Commande " + numero +" : " +"\n Date         : " + comm.getDate() + "\n" + " Client     :  " +comm.getClient()+ "\n" + " refProduits : " +"\n";
                for(int i=0; i<comm.getReferences().size();i++){
                    res1+="        " + comm.getReferences() + "\n";
                }
                trouver = true;
            }
        }
        if (!trouver) {
            res+="Cette commande n'existe pas";
        }

        return res + res1 + "\n" ;
    }

    // Chargement du fichier de stock
    //
    private void initialiserStock(String nomFichier) {
        String[] lignes = Terminal.lireFichierTexte(nomFichier);
        for (String ligne : lignes) {
            System.out.println(ligne);
            String[] champs = ligne.split("[;]", 4);
            String reference = champs[0];
            String nom = champs[1];
            double prix = Double.parseDouble(champs[2]);
            int quantite = Integer.parseInt(champs[3]);
            Produit p = new Produit(reference, nom, prix, quantite);
            stock.add(p);
        }
    }

    private void initialiserCommandes(String nomFichier) {
        String[] lignes = Terminal.lireFichierTexte(nomFichier);
        for (String ligne : lignes) {
            System.out.println(ligne);
            String[] champs = ligne.split("[;]", 4);
            int numero = Integer.parseInt(champs[0]);
            String date = champs[1];
            String client = champs[2];
            String[] referencesArray = champs[3].split(","); // Divisez la chaîne des références en un tableau de chaînes
            ArrayList<String> references = new ArrayList<>(Arrays.asList(referencesArray)); // Créez un ArrayList à partir du tableau de chaînes
            Commande c = new Commande(numero, date, client, references);
            commandes.add(c);
        }
    }
    public String livrer(){
        String res = "Les commandes non livres : \n" ;
        for (Produit produit: stock
             ) {
            for (Commande commande: commandes

                 ) {
                int numCommande=commande.getNumero();
                for (String refference: commande.getReferences()
                     ) {
                    String r = refference.substring(0,refference.length()-2);
                    int compteur =
                    int quantiteCommande = Integer.parseInt(refference.substring(refference.length() - 1));
                    if(r.equals(produit.getReference())){
                            if (quantiteCommande<=produit.getQuantite()){
                                produit.setQuantite(produit.getQuantite()-quantiteCommande);
                                compteur-=1;
                                System.out.println(compteur);
                                }
                            else{
                                int a = quantiteCommande-produit.getQuantite();
                                commande.setExplication("il manque " + a + " " + r + "\n");
                            }

                    }
                    if (compteur == 0){
                        commande.setaEteLivre(true);
                    }
                    }
                }
            }
        for (Commande commande: commandes
             ) {
            if(commande.aEteLivre()){
                commandes.remove(commande);
            }
            else{
                res += "Commande : " + commande.getNumero() + "\n" + "Date : " + commande.getDate() + "\n" + "Client : "  + commande.getClient() + "\n" + "RefProduits : " +  commande.getReferencesToString(commande.getReferences()) + "\n" + commande.getExplication() + "\n";
            }
        }
        return  res;
        }


    public ArrayList<Produit> getStock() {
        return stock;
    }

    public void setStock(ArrayList<Produit> stock) {
        this.stock = stock;
    }

    public void setCommandes(ArrayList<Commande> commandes) {
        this.commandes = commandes;
    }
}