package projet;

import java.util.*;

import util.*;

// Classe de definition du site de vente
//
public class Site {
    private ArrayList<Produit> stock;       // Les produits du stock
    private ArrayList<Commande> commandes;  // Les bons de commande
    private List<Commande> commandesLivres = new ArrayList<>();

    private List<Commande> commandesNonLivres = new ArrayList<>();




    // Constructeur
    //
    public Site() {
        stock = new ArrayList<Produit>();

        // lecture du fichier data/Produits.txt
        //  pour chaque ligne on cree un Produit que l'on ajoute a stock
        initialiserStock("data/Produits.txt");

        //  lecture du fichier data/Commandes.txt
        //  pour chaque ligne on cree une commande ou on ajoute une reference
        //  d'un produit a une commande existante.
        // AC AC

        commandes = new ArrayList<Commande>();
        initialiserCommandes("data/Commandes.txt");


    }private void initialiserStock(String nomFichier) {
        String[] lignes = Terminal.lireFichierTexte(nomFichier);
        for (String ligne : lignes) {
            System.out.println(ligne);
            String[] champs = ligne.split("[;]", 4);
            String reference = champs[0];
            String nom = champs[1];
            double prix = Double.parseDouble(champs[2]);
            int quantite = Integer.parseInt(champs[3]);
            Produit p = new Produit(reference, nom, prix, quantite);
            stock.add(p);
        }
    }

    private void initialiserCommandes(String nomFichier) {
        String[] lignes = Terminal.lireFichierTexte(nomFichier);
        for (String ligne : lignes) {
            System.out.println(ligne);
            String[] champs = ligne.split("[;]", 4);
            int numero = Integer.parseInt(champs[0]);
            String date = champs[1];
            String client = champs[2];
            String[] referencesArray = champs[3].split(","); // Divisez la chaîne des références en un tableau de chaînes
            ArrayList<String> references = new ArrayList<>(Arrays.asList(referencesArray)); // Créez un ArrayList à partir du tableau de chaînes
            Commande c = new Commande(numero, date, client, references);
            commandes.add(c);
        }
    }
    //methode qui partage un string en deux
    public static String[] couperString(String input) {
        String[] parts = input.split("=");
        if (parts.length == 2) {
            return parts;
        } else {
            return new String[] { "Invalid", "Input" };
        }
    }

    // Methode qui retourne sous la forme d'une chaine de caractere
    //  tous les produits du stock
    //
    public String listerTousProduits() {
        String res = "";
        for (Produit prod : stock)
            res = res + prod.toString() + "\n";

        return res;
    }
    public static Map<Integer, Commande> convertToHashMap(ArrayList<Commande> commandes) {
        Map<Integer, Commande> commandesMap = new HashMap<>();

        for (Commande commande : commandes) {
            int numero = commande.getNumero();

            // If the command number is not in the map, create a new Commande object
            if (!commandesMap.containsKey(numero)) {
                commandesMap.put(numero, new Commande(commande.getNumero(), commande.getDate(), commande.getClient(), new ArrayList<>()));
            }for (String reference : commande.getReferences()) {
                String[] parts = reference.split("=");
                if (parts.length == 2) {
                    String ref = parts[0];
                    int quantity = Integer.parseInt(parts[1]);
                    commandesMap.get(numero).getReferences().add(ref + "=" + quantity);
                }
            }

        }

        return commandesMap;
    }


    // Methode qui retourne sous la forme d'une chaine de caractere
    //  toutes les commandes
    //

    public String listerToutesCommandes() {

        String res = "";
        int compteur = 0;

        // Parcours toutes les commandes dans la liste en utilisant la methode listerCommande
        for (Commande comm : commandes) {
            if (comm.getNumero()!=compteur)
            res += listerCommande(comm.getNumero());
            compteur=comm.getNumero();
            ;
        }
        // Retourne la chaîne de caractères résultante
        return res;
    }

    // Methode qui retourne sous la forme d'une chaine de caractere
    //  une commande
    public String listerCommande(int numero) {
        String res = "";
        String res1 = "";
        boolean trouver = false;

        for (Commande comm : commandes) {
            if (comm.getNumero() == numero) {
                res="Commande " + numero +" : " +"\n Date         : " + comm.getDate() + "\n" + " Client     :  " +comm.getClient()+ "\n" + " refProduits : " +"\n";
                for(int i=0; i<comm.getReferences().size();i++){
                    res1+="        " + comm.getReferences() + "\n";
                }
                trouver = true;
            }
        }
        if (!trouver) {
            res+="Cette commande n'existe pas";
        }

        return res + res1 + "\n" ;
    }

public Object[] livrable(Map<Integer, Commande> mapDeCommandes, int numeroDeCommande) {
    Commande commande = mapDeCommandes.get(numeroDeCommande);

    if (commande == null) {
        return new Object[]{false, "Commande pas trouvé"};
    }
    boolean commandeLivrable = true;

    for (String res : commande.getReferences()) {
        String reff = res.split("=")[0];
        int quantite = Integer.parseInt(res.split("=")[1]);
        System.out.println("commande numero = " + numeroDeCommande + ", reff = " + reff + " quantite : " + quantite);

        for (Produit prod: stock) {

            boolean reffMatched = false;

            if (reff.equals(prod.getReference()) && quantite <= prod.getQuantite()) {
                prod.setQuantite(prod.getQuantite() - quantite);
                reffMatched = true;
                System.out.println("quantide de produit : " + prod.getReference()  +" " + prod.getQuantite());

            } else if (reff.equals(prod.getReference()) && quantite > prod.getQuantite()) {
                int manque = quantite - prod.getQuantite();
                commandeLivrable = false;
                System.out.println("test else");
                System.out.println("manque de produit " + prod.getReference() + " " + manque);
                commande.setExplication("Il manque : " + manque + " " + reff + "\n");
            }
            if (reffMatched) {
                break;
            }
        }
    }
    commande.setaEteLivre(commandeLivrable);
    System.out.println("etat commande : " + commande.aEteLivre());
    if(commande.aEteLivre()){
        if (!commandesLivres.contains(commande)) {
            commandesLivres.add(commande);
        }
        ArrayList<Commande> newCommandes = new ArrayList<>();
        for (Commande comm : commandes) {
            if (comm.getNumero() != commande.getNumero()) {
                newCommandes.add(comm);
            }
        }
        commandes = newCommandes;
    }
    else{
        if (!commandesNonLivres.contains(commande)) {
            commandesNonLivres.add(commande);
        }
    }

    String res = "Commande " + numeroDeCommande;

    return new Object[]{commande.aEteLivre(), commande, res};
}


public List<Commande> livrerTous() {

    Map<Integer, Commande> commandesMap = convertToHashMap(commandes);

    for (int i = 1; i<=commandesMap.size(); i++) {
        Object[] result = livrable(commandesMap, i);

    }
    return commandesNonLivres;
}

}